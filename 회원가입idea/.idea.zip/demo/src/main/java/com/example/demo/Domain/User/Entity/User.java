package com.example.demo.Domain.User.Entity;






public class User {
}
